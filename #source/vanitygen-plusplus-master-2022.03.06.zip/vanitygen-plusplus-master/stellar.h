#ifndef VANITYGEN_PLUSPLUS_STELLAR_H
#define VANITYGEN_PLUSPLUS_STELLAR_H

#include <stddef.h>

void strkey_encode(unsigned char versionByte, unsigned char *in, size_t in_len, unsigned char *out);

#endif //VANITYGEN_PLUSPLUS_STELLAR_H
